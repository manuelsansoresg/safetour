<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TourImages extends Model
{
    protected $primaryKey = 'tour_id';


}
