<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Tour extends Model
{
    protected $fillable  = ['name', 'description', 'price', 'slug'];

    public static function getAll()
    {
        $tour = Tour::select('tours.id','tours.name', 'description', 'price', 'slug', 'tour_images.name as image')
                        ->join('tour_images', 'tour_images.tour_id', '=' , 'tours.id')
                        ->get();
        return $tour;
    }

    public static function saveEdit($request, $path, $id = null)
    {
        if($id == null){
            $tour = new Tour($request->except('_token', 'image'));
            $tour->slug = Str::slug($request->name);
            $tour->save();
        }else{
            $tour = Tour::find($id);
            $tour->fill($request->except('_token', 'image'));
            $tour->slug = Str::slug($request->name);
            $tour->update();
        }

        if ($request->hasFile('image') != false) {

            $path = '.'.$path.'/'. $tour->id;
            if ($id != null) {
                $image = TourImages::find($tour->id);
                @unlink($path .'/'.$image->name);
                @unlink($path . '/thumb_' . $image->name);
            }

            $image_cover      = $request->file('image');
            $new_image        = uploadImage($_FILES['image'], $image_cover, $path, true);
            $set_img          = new TourImages();
            $set_img->tour_id = $tour->id;
            $set_img->name    = $new_image;
            $set_img->save();
        }

    }

    public static function drop($tour_id, $path)
    {
        $tour = Tour::find($tour_id);
        $path = '.'.$path.'/'. $tour->id;

        $image = TourImages::find($tour_id);
        @unlink($path.'/'.$image->name);
        @unlink($path. '/thumb_'.$image->name);

        $tour->delete();
        $image->delete();
    }
}
