<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = ['title', 'total_price', 'name', 'watsapp', 'pickuppoint_id', 'quantity', 'date', 'email', 'type_pay_id', 'token', 'status'];

    public static function getTotal($request)
    {
        $price      = $request->price;
        $persons    = $request->persons;
        $payed_sel  = $request->payed;
        $payed      = TypePay::find($payed_sel);
        $type_price = $payed->price;

        $percent    = $type_price / 100;
        $subtotal   = $price * $percent;
        $total      = $price;
        if( $payed->type != '' ){
            $total   = ($payed->type == '-' ) ? $price - $subtotal : $price + $type_price;
        }
        $total = $total * $persons;
        return $total;
    }

    public static function setUpOrder($request, $total)
    {
        $tour = Tour::where('slug', $request->tour_slug)->first();

        $order                     = new Order();
        $order->title              = 'Tour-'.$tour->name;
        $order->quantity           = $request->persons;
        $order->total_price        = $total;
        $order->email              = $request->email;
        $order->type_pay_id        = $request->payed;
        $order->name               = $request->name;
        $order->watsapp            = $request->name;
        $order->pickuppoint_id     = $request->point;
        $order->date               = $request->date;
        $order->tour_id            = $tour->id;
        $order->save();

        return $order;
    }

    public static function updatePrefId($order_id, $pref_id)
    {
        $order          = Order::find($order_id);
        $order->pref_id = $pref_id;
        $order->update();
    }

    public static function updateApproved($request)
    {

        $order = Order::where('pref_id', $request->preference_id)->first();
        $order->status = $request->collection_status;
        $order->update();
    }

}
