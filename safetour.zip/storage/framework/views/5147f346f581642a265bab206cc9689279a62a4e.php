<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-dark bg-dark d-flex justify-content-center align-items-center text-center  py-3 mt-2">
        <p class="h1"> <?php echo e($tour->name); ?> </p>
    </nav>

    <div class="container preorder">

        <div class="row mt-5 justify-content-center">
            <div class="col-12 col-md-6 ">
                <div class="card preorder__card">
                    <div class="card-header text-center bg-success text-white">
                        <h4>RESERVATION APPROVED</h4>
                    </div>
                    <div class="card-body">


                        <div class="form-group row">
                            <label for="staticEmail" class="col-sm-5 col-form-label font-weight-bold">NAME</label>
                            <div class="col-sm-7">
                                <input type="text" name="name" id="name" class="form-control" readonly value="<?php echo e($order->name); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="staticEmail" class="col-sm-5 col-form-label font-weight-bold">WATSAPP</label>
                            <div class="col-sm-7">
                                <input type="text" name="watsapp" id="watsapp"  class="form-control" readonly value="<?php echo e($order->watsapp); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="staticEmail" class="col-sm-5 col-form-label font-weight-bold">CHOSE POINT OF PICKUP</label>
                            <div class="col-sm-7">
                                <select name="point" id="point" class="form-control" required>
                                    <option value="">Select one option</option>
                                    <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($point->id); ?>" <?php echo e(($order->pickuppoint_id == $point->id)? 'selected' : ''); ?>><?php echo e($point->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="staticEmail" class="col-sm-5 col-form-label font-weight-bold">#PERSONS</label>
                            <div class="col-sm-7">
                                <input type="number" min="1" onchange="updateTotal()"  class="form-control" id="persons" name="persons" value="<?php echo e($order->quantity); ?>" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="staticEmail" class="col-sm-5 col-form-label font-weight-bold">DATE TOUR</label>
                            <div class="col-sm-7">
                                <input type="text"  class="form-control" name="date" id="date" value="<?php echo e($order->date); ?>" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="staticEmail" class="col-sm-5 col-form-label font-weight-bold">EMAIL</label>
                            <div class="col-sm-7">
                                <input type="email" name="email" id="email"  class="form-control"  readonly value="<?php echo e($order->email); ?>">
                            </div>
                        </div>
                        <?php $cont = 0; ?>
                        <?php $__currentLoopData = $type_pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $cont = $cont +1;
                            $checked = ($order->type_pay_id == $type_pay->id) ? 'checked' : '';
                            ?>
                            <div class="form-group row">
                                <label for="staticEmail" class="col-12 col-md-5 col-form-label font-weight-bold"><?php echo e(strtoupper($type_pay->name)); ?></label>
                                <div class="col-sm-7">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="payed[]"  <?php echo e($checked); ?> readonly>
                                        <label class="form-check-label" for="exampleRadios1">
                                            TOTAL <?php echo e(strtoupper($type_pay->legend)); ?>

                                        </label>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group row">
                            <label for="staticEmail" class="col-sm-5 col-form-label font-weight-bold">TOTAL</label>
                            <div class="col-sm-7">

                                <div class="col-12 text-center bg-gray-light py-2 h5" id="d_total"> <?php echo e(price($order->total_price)); ?> MXN</div>
                            </div>
                        </div>




                    </div>
                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\safetour\resources\views/mercado_pago/thanks.blade.php ENDPATH**/ ?>