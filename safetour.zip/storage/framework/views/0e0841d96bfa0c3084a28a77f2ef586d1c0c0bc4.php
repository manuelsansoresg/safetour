<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css" rel="stylesheet" >
    <link rel="stylesheet" href="<?php echo e(asset('vendor_assets/jquery-ui-1.12.1.custom/jquery-ui.min.css')); ?>">

    <title>SafeTour</title>
</head>
<body>
<nav class="navbar navbar-dark  bg-gray">
    <a class="navbar-brand" href="/">Safe Tour</a>
    <form class="form-inline">
        <select name="" id="" class="form-control">
            <option value="">Seleccione una opción </option>
        </select>
    </form>
</nav>
<nav class="navbar navbar-dark bg-dark landing__tours py-3">
    <div>Can Pay at Pick Up</div>
    <div>We pick you up & we bring you back</div>
    <div>5% Disscount paying On Line</div>
    <div>Safe Tour Mx</div>
</nav>


<?php echo $__env->yieldContent('content'); ?>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_assets/admin_lte/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_assets/jquery-ui-1.12.1.custom/jquery-ui.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\safetour\resources\views/layouts/landing.blade.php ENDPATH**/ ?>