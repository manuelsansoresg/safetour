@extends('layouts.landing')

@section('content')
    <div class="container">
        <div class="row mt-2">
            <div class="col-12">
                Chichen Itzá / Coba / Tulum / Holbox
            </div>
        </div>
    </div>

    <nav class="navbar navbar-dark bg-dark  text-center justify-content-center align-items-center py-3 py-md-5 mt-2">
        <div class="h3">
            Visit México
        </div>
    </nav>
    <div class="landing">
        <?php $cont = 0; ?>
        @foreach($tours as $tour)
            <?php $cont = $cont +1; ?>
            <?php $image =  $path.'/'.$tour->id.'/'.$tour->image  ?>
            <div style="background : url('{{ $image }}')  no-repeat center;" class="landing__img-tour">
                <div class="landing__img-tour__legend">
                    <div class="text-center float-md-right px-3  minimize{{ $cont }} landing__information">TOUR INFORMATION / RESERVATION HERE</div>
                    <div class="landing__img-tour__legend2 minimize{{ $cont }}">
                        <div class="mt-2"> <h1>{{ $tour->name }}</h1> </div>
                        <div class="mt-2 col col-md-3"> <a onclick="loadMore('{{ $cont  }}')"  class="btn btn-warning btn-lg btn-block"> <span class="font-weight-bold">INFORMATION</span> </a>  </div>
                    </div>

                    <div class="landing__img-tour__legend2 landing__img-tour__legend2big more" id="more{{ $cont }}" style="display: none">

                        <div class="col-12 col-md-3 text-center">
                            <span class="h1">{{ $tour->name }}</span><sup><span class="badge "> <a class="cursor" onclick="closeMore('{{ $cont }}')"><i class="fas fa-times-circle fa-3x"></i></a> </span></sup>
                        </div>
                        <div class="col-12 col-md-4 ">
                            <div class="scrollBody landing__img-tour__legend2content text-white">
                                {!! $tour->description !!}
                            </div>
                            <div class="col-12 col-md-8 mt-4 h5 font-weight-bold">
                                <span>YES Can pay at PickUp Time</span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            {{ Form::open(['route' => ['pay.preorder', $tour->slug], 'method' => 'GET', 'class' => 'needs-validation', 'novalidate']) }}
                            <div class="row">
                                <div class="col-2">
                                    <input type="number" onchange="setTotal('{{ $cont }}')" min="1"  class="input-number" name="persons[]" id="persons{{ $cont }}" value="1">
                                </div>
                                <div class="col-10">
                                    <div class="h5 label-white">#persons</div>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-2">
                                    <i class="far fa-calendar-alt icon-calendar"></i>
                                </div>
                                <div class="col-10 text-sm-left">
                                    <input type="text" name="date[]" id="datepicker{{ $cont }}" class="datepicker" autocomplete="off">
                                    <input type="hidden"  name="price[]"  id="price{{ $cont }}" value="{{ $tour->price }}">
                                    <input type="hidden"  name="slug[]"   value="{{ $tour->slug }}">
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-2">

                                </div>
                                <div class="col-10 text-left text-sm-left">
                                    <input type="text" name="total[]"  id="total{{ $cont }}" class="input"  value="TOTAL {{ $tour->price }} MXN" >
                                </div>

                            </div>

                            <div class="row mt-2">
                                <div class="offset-md-2 col-10">
                                    <span>5% disscount paying online</span>
                                </div>
                            </div>

                            <div class="row mt-2">
                                <div class="offset-md-2 col-12 col-md-6">
                                    <button class="btn btn-warning btn-lg btn-block">BUY</button>
                                </div>
                            </div>

                            <div class="row mt-2 mt-md-5">
                                <div class="offset-md-2 col-12 col-md-6">
                                    <button class="btn btn-primary btn-lg btn-block">I want only a Reservation</button>

                                </div>
                            </div>



                            {{ Form::close() }}
                        </div>
                    </div>

                </div>
            </div>
            <div class="bg-dark text-white py-3 px-2 landing__img-tour__bottom-info">
                THE RESERVATION NAME WILL BE THE SAME AS THE CARD HOLDER / <span class="font-weight-bold">YOU CAN PAY AT PICK UP 10% COMISSION PAYING WTH CREDIT / DEBIT CARD </span>
            </div>
        @endforeach
    </div>
@endsection
