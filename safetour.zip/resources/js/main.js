$(document).ready(function() {
    if ( $(".summer").length > 0 ) {
        $('.summer').summernote(
            {
                height: 200,
                fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Campton-Medium', 'Roboto-Regular', 'Campton-Light' , 'Campton-Book', 'Campton-ExtraBold', 'Campton-SemiBoldItalic'],
                fontNamesIgnoreCheck: ["Campton-Medium", "Campton-Light", 'Campton-Book', 'Roboto-Regular', 'Campton-ExtraBold', 'Campton-SemiBoldItalic']
            }
        );
    }
    if ( $(".datepicker").length > 0 ) {
        $( ".datepicker" ).datepicker();
        $( ".datepicker" ).datepicker( "option", "dateFormat", 'd M, y' );
    }

    $('.datepicker_cotizador').datepicker({
        dateFormat: 'd M, y'
    });


    if ( $(".landing").length > 0 ) {



        window.setTotal = function (count) {

            var persons =  parseInt( $('#persons'+count).val());
            var datepicker = $('#datepicker'+count).val();
            var price = parseFloat($('#price'+count).val());

            var total = persons * price;

            $('#total'+count).val('TOTAL '+ total + ' MXN');

            console.log('persons'+persons);
        }

    }

    if ( $(".more").length > 0 ) {

        window.loadMore = function (divId) {
            $('#more'+divId+'').fadeIn('slow');
            $('.minimize'+divId+'').hide();
        }

        window.closeMore = function (divId) {
            $('#more'+divId+'').hide();
            $('.minimize'+divId+'').fadeIn('slow');

        }

    }

});

(function () {
    'use strict';
    window.addEventListener('load', function () {
        //Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        //Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function (form) {
            form.addEventListener('submit', function (event) {
                if (form.checkValidity() === false) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    }, false);
})();


require('./components/order');
